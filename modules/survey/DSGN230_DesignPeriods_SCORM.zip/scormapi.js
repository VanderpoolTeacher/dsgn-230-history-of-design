/*  SCORM 1.2 API Wrapper  */
var SCORMapi = (function () {
  var api = null;
  var data = {};

  function findAPI(win) {
    var attempts = 0;
    while (win && !win.API && attempts < 10) {
      if (win.parent && win.parent !== win) { win = win.parent; }
      else if (win.opener) { win = win.opener; }
      else { break; }
      attempts++;
    }
    return win && win.API ? win.API : null;
  }

  function init() {
    api = findAPI(window);
    if (api) {
      api.LMSInitialize("");
      var bookmark = api.LMSGetValue("cmi.core.lesson_location");
      if (bookmark) data.bookmark = bookmark;
    }
    return !!api;
  }

  function setValue(key, val) {
    data[key] = val;
    if (api) api.LMSSetValue(key, val);
  }

  function getValue(key) {
    if (api) return api.LMSGetValue(key);
    return data[key] || "";
  }

  function commit() { if (api) api.LMSCommit(""); }

  function finish() {
    if (api) { api.LMSCommit(""); api.LMSFinish(""); }
  }

  function setScore(score) {
    setValue("cmi.core.score.raw", score);
    setValue("cmi.core.score.min", "0");
    setValue("cmi.core.score.max", "100");
  }

  function setComplete(status) {
    setValue("cmi.core.lesson_status", status); // "passed","failed","completed"
    commit();
  }

  function setBookmark(loc) {
    setValue("cmi.core.lesson_location", loc);
    commit();
  }

  function getBookmark() {
    return getValue("cmi.core.lesson_location");
  }

  return {
    init: init,
    setValue: setValue,
    getValue: getValue,
    commit: commit,
    finish: finish,
    setScore: setScore,
    setComplete: setComplete,
    setBookmark: setBookmark,
    getBookmark: getBookmark
  };
})();
